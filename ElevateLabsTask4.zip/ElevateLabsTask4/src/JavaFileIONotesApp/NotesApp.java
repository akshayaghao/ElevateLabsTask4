package JavaFileIONotesApp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class NotesApp {

    private static final String FILE_NAME = "notes.txt";

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        boolean running = true;

        System.out.println("^^^ WELCOME TO OUR TODO NOTES APP ^^^");

        while (running) {
            System.out.println("\nCHOOSE A CORRECT OPTION :->");
            System.out.println("1. ADD A NEW NOTE");
            System.out.println("2. VIEW ALL NOTES");
            System.out.println("3. EXIT");
            System.out.print("ENTER YOUR CHOICE :-> ");

            String choice = sc.nextLine();

            switch (choice) {
                case "1":
                    addNote(sc);
                    break;

                case "2":
                    viewNotes();
                    break;

                case "3":
                    running = false;
                    System.out.println("EXITING NOTES APP.");
                    break;

                default:
                    System.out.println("Invalid Choice, Please Enter 1, 2, or 3.");
            }
        }
        sc.close();
    }

    
    private static void addNote(Scanner scanner) {
        System.out.print("Enter Your Note : -> ");
        String note = scanner.nextLine();

        try (FileWriter fw = new FileWriter(FILE_NAME, true);
             BufferedWriter bw = new BufferedWriter(fw)) {

            bw.write(note);
            bw.newLine();
            System.out.println("Note Added Successfully");
        } catch (IOException e) {  // fixed exception type from "IO" to "IOException"
            System.out.println("Error writing To File : " + e.getMessage());
        }
    }

    
    private static void viewNotes() {
        System.out.println("Your Notes Here:");

        try (FileReader fr = new FileReader(FILE_NAME);
             BufferedReader br = new BufferedReader(fr)) {

            String line;
            boolean empty = true;

            
            while ((line = br.readLine()) != null) {
                System.out.println("- " + line);
                empty = false;
            }

            if (empty) {
                System.out.println("Notes not found.");
            }

        } catch (FileNotFoundException e) {
            System.out.println("No Notes Found. Please Add Notes.");
        } catch (IOException e) {
            System.out.println("Error Reading File :-> " + e.getMessage());
        }
    }
}
